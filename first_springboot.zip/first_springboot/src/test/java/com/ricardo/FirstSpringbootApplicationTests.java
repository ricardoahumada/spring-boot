package com.ricardo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
